import datetime
import os

import pyautogui
import time
import xlrd
import pyperclip
from pynput.mouse import Button, Controller as c_mouse
# 编号1 双一拣
def searchMoveClick(img, x=0, y=0, clickNum=1):
    # 找到【异常分类】
    while True:
        try:
            location = pyautogui.locateCenterOnScreen(img, confidence=0.9)
            if location is not None:
                pyautogui.moveTo(location.x * 0.5 + x, location.y * 0.5 + y)
                pyautogui.click(clicks=clickNum)
                time.sleep(1)
                break
        except pyautogui.ImageNotFoundException:
            time.sleep(1)
            print("未找到匹配图片,1秒后重试" + img)
            print('ImageNotFoundException: image not found')

def dataExport(pic_path,name):
    # 点击下拉菜单中的【任务管理】
    print("任务管理")
    img = os.path.join(pic_path, 'task_management.png')
    # searchMoveClick(1, lOrR, img, reTry)
    searchMoveClick(img, 0, 0, 1)

    # 点击下拉菜单中的【导出任务管理】
    print('导出任务管理')
    img = os.path.join(pic_path, 'export_task_management.png')
    searchMoveClick(img, 0, 0, 1)

    time.sleep(3)

    # 在文件名中搜索
    img = os.path.join(pic_path, 'inquire.png')
    # location = pyautogui.locateCenterOnScreen(img, confidence=0.7)
    # pyautogui.moveTo(location.x * 0.5 - 50, location.y * 0.5)
    # pyautogui.click(clicks=2)
    searchMoveClick(img, -50, 0, 1)
    pyautogui.typewrite(name, interval=0.1)
    pyautogui.press('enter')

    # 点击【查询】
    while True:
        img = os.path.join(pic_path, 'inquire.png')
        searchMoveClick(img, 0, 0, 1)
        # pyautogui.moveTo(location.x * 0.5, location.y * 0.5)
        # pyautogui.click(clicks=1)
        # 点击【下载】
        img = os.path.join(pic_path, 'downloadV2.png')
        try:
            location = pyautogui.locateCenterOnScreen(img, confidence=0.9)
            if location is not None:
                pyautogui.moveTo(location.x * 0.5, location.y * 0.5)
                pyautogui.click(clicks=1)
                time.sleep(1)
                break
        except pyautogui.ImageNotFoundException:
            time.sleep(1)
            print("未找到匹配图片,1秒后重试" + 'downloadV2.png')
            print('ImageNotFoundException: image not found')

    time.sleep(2)

    pyautogui.typewrite(name, interval=0.1)
    # pyautogui.press('enter')
    time.sleep(1)

    # 选择保存目录
    img = os.path.join(pic_path, 'choice.png')
    searchMoveClick(img, 0, 0, 1)
    # mouseClick(1, lOrR, img, reTry)

    # 保存
    img = os.path.join(pic_path, 'save.png')
    searchMoveClick(img, 0, 0, 1)
    # mouseClick(1, lOrR, img, reTry)

if __name__ == '__main__':
    lOrR = 'left'
    pic_path = '/Users/flash/PycharmProjects/learnpython/flash/zidshw'
    reTry = 1
    today = datetime.date.today()
    todaydiminish1 = (today + datetime.timedelta(days=-1)).strftime("%Y-%m-%d")
    title = 'udyijm'
    concont = str(today) + title
    mouse = c_mouse()

    # 找到【库内】
    img = os.path.join(pic_path, '3-kunz.png')
    # mouseClick(2, lOrR, img, reTry)
    searchMoveClick(img, 0, 0, 2)

    # 找到【异常单】
    img = os.path.join(pic_path, '3-yiihdj.png')
    # mouseClick(1, lOrR, img, reTry)
    searchMoveClick(img, 0, 0, 1)

    # 找到【异常分类】
    img = os.path.join(pic_path, '3-yiihfflz.png')
    searchMoveClick(img, 50, 10, 1)

    # 等待2s
    time.sleep(2)

    # 下移30像素，找到少货并点击
    pyautogui.move(0, 30)
    pyautogui.click()

    # 找到【提交时间】
    img = os.path.join(pic_path, '3-tijcuijm.png')
    searchMoveClick(img, 40, 0, 1)

    # 找到【时间标记】
    img = os.path.join(pic_path, '3-uijmbcji.png')
    searchMoveClick(img, 0, -30, 1)

    time.sleep(1)
    pyautogui.hotkey('command', 'a')
    time.sleep(1)
    # 输入昨天的日期
    pyautogui.typewrite(todaydiminish1, interval=0.1)
    pyautogui.move(140, 0)

    # 原有的方法存在问题，无法点击，使用新的包
    mouse = c_mouse()
    mouse.click(Button.left, 2)
    # 输入 23 点
    pyautogui.typewrite('23', interval=0.1)

    # 找到【确定】
    img = os.path.join(pic_path, '3-qtdy.png')
    searchMoveClick(img, 0, 0, 1)
    # mouseClick(1, lOrR, img, reTry)
    time.sleep(1)

    # 找到【查询】
    img = os.path.join(pic_path, '3-iaxp.png')
    searchMoveClick(img, 0, 0, 1)
    # mouseClick(1, lOrR, img, reTry)
    time.sleep(3)

    # 找到【全部导出】
    img = os.path.join(pic_path, '3-qrbudkiu.png')
    searchMoveClick(img, 0, 0, 1)
    # mouseClick(1, lOrR, img, reTry)
    time.sleep(1)

    # 找到【任务名称】
    print("任务名称")
    img = os.path.join(pic_path, '3-rfwumyig.png')
    searchMoveClick(img, 0, 50, 1)

    time.sleep(1)
    pyautogui.typewrite(concont, interval=0.1)
    pyautogui.press('enter')

    # 找到【确定】
    print("确定")
    img = os.path.join(pic_path, '3-qtdy.png')
    searchMoveClick(img, 0, 0, 1)
    # mouseClick(1, lOrR, img, reTry)
    time.sleep(3)

    # ############################################################# 导出文件
    dataExport(pic_path, concont)



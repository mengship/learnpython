import datetime
import os

import pandas as pd
import pyautogui
import time
import xlrd
import pyperclip
from pynput.mouse import Button, Controller as c_mouse
from flash.zidshw.udyijm import searchMoveClick, dataExport

# 编号5 积压单昨日取消
if __name__ == '__main__':
    lOrR = 'left'
    pic_path = '/Users/flash/PycharmProjects/learnpython/flash/zidshw'
    reTry = 1
    startDay='2024-03-01'
    today = datetime.date.today()
    todayadd45 = (today + datetime.timedelta(days=10)).strftime("%Y-%m-%d")
    print(todayadd45)
    title = 'Backlogabolish'
    concont = str(today) + title


    mouse = c_mouse()

    while startDay < todayadd45:
        startDayAdd45 = (pd.Timestamp(startDay) + datetime.timedelta(days=10)).strftime("%Y-%m-%d")
        name = str(today) + startDay + '~' + startDayAdd45 + title + '1'

        # 找到【库内】
        img = os.path.join(pic_path, '3-kunz.png')
        # mouseClick(2, lOrR, img, reTry)
        searchMoveClick(img, 0, 0, 2)

        # 找到【差异调整】
        img = os.path.join(pic_path, '5-iayitcvg.png')
        # mouseClick(2, lOrR, img, reTry)
        searchMoveClick(img, 0, 0, 1)

        time.sleep(3)

        # 找到【状态】
        img = os.path.join(pic_path, '5-status.png')
        searchMoveClick(img, 50, 0, 1)
        # location = pyautogui.locateCenterOnScreen(img, confidence=0.9)
        # print('________location__________>', location)
        # pyautogui.moveTo(location.x * 0.5 + 50, location.y * 0.5)
        # pyautogui.click(clicks=1)
        time.sleep(2)
        pyautogui.move(0, 175)
        pyautogui.click(clicks=1)


        # 找到【创建时间】
        img = os.path.join(pic_path, '5-idjmuijm.png')
        searchMoveClick(img, 50, 0, 1)
        # location = pyautogui.locateCenterOnScreen(img, confidence=0.9)
        # print('________location__________>', location)
        # pyautogui.moveTo(location.x * 0.5 + 50, location.y * 0.5)
        # pyautogui.click(clicks=1)
        pyautogui.move(0, 50)
        pyautogui.click(clicks=1)
        mouse.click(Button.left, 3)
        pyautogui.typewrite(startDay, interval=0.1)
        pyautogui.move(400, 0)
        pyautogui.click(clicks=1)
        mouse.click(Button.left, 3) # 左键连点三次
        pyautogui.typewrite(startDayAdd45, interval=0.1)

        # 找到【搜索】
        img = os.path.join(pic_path, '5-搜索.png')
        # mouseClick(1, lOrR, img, reTry)
        searchMoveClick(img, 0, 0, 1)

        time.sleep(10)

        # 找到【导出】
        img = os.path.join(pic_path, '5-导出.png')
        # mouseClick(1, lOrR, img, reTry)
        searchMoveClick(img, 0, 0, 1)

        # 找到【任务名称】
        img = os.path.join(pic_path, '5-任务名称.png')
        searchMoveClick(img, 0, 50, 1)
        # location = pyautogui.locateCenterOnScreen(img, confidence=0.9)
        # print('________location__________>', location)
        # pyautogui.moveTo(location.x * 0.5 , location.y * 0.5 + 50)
        # pyautogui.click(clicks=1)
        pyautogui.typewrite(name , interval=0.1)
        pyautogui.press('enter')

        while True:
            # 找到【确定】
            img = os.path.join(pic_path, '5-确定.png')
            # mouseClick(1, lOrR, img, reTry)
            searchMoveClick(img, 0, 0, 1)

            # 点击【下载】
            img = os.path.join(pic_path, '有任务正在下载.png')
            try:
                location = pyautogui.locateCenterOnScreen(img, confidence=0.9)
                if location is not None:
                    pyautogui.moveTo(location.x * 0.5, location.y * 0.5)
                    print("有任务正在下载" + '有任务正在下载.png，等待3s')
                    time.sleep(3)
            except pyautogui.ImageNotFoundException:
                break

        dataExport(pic_path, name)
        # # 点击下拉菜单中的【任务管理】
        # img = os.path.join(pic_path, 'task_management.png')
        # # mouseClick(1, lOrR, img, reTry)
        # searchMoveClick(img, 0, 0, 1)
        #
        # # 点击下拉菜单中的【导出任务管理】
        # # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/export_task_management.png'
        # img = os.path.join(pic_path, 'export_task_management.png')
        # mouseClick(1, lOrR, img, reTry)
        # searchMoveClick(img, 0, 0, 1)
        #
        # time.sleep(270)
        #
        # # 在文件名中搜索
        # # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/inquire.png'
        # img = os.path.join(pic_path, 'inquire.png')
        # searchMoveClick(img, -50, 0, 2)
        # # location = pyautogui.locateCenterOnScreen(img, confidence=0.7)
        # # pyautogui.moveTo(location.x * 0.5 - 50, location.y * 0.5)
        # # pyautogui.click(clicks=2)
        # pyautogui.typewrite(startDay+ '~'+ startDayAdd45 + title, interval=0.1)
        # pyautogui.press('enter')
        #
        # # 点击【查询】
        # # pyautogui.moveTo(location.x * 0.5, location.y * 0.5)
        # # pyautogui.click(clicks=1)
        # searchMoveClick(img, 0, 0, 1)
        #
        # time.sleep(2)
        #
        # # 点击【下载】
        # # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/downloadV2.png'
        # img = os.path.join(pic_path, 'downloadV2.png')
        # # mouseClick(1, lOrR, img, reTry)
        # searchMoveClick(img, 0, 0, 1)
        # time.sleep(2)
        #
        # pyautogui.typewrite(startDay+ '~'+ startDayAdd45 + title, interval=0.1)
        # # pyautogui.press('enter')
        #
        # # 选择保存目录
        # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/choice.png'
        # mouseClick(1, lOrR, img, reTry)
        #
        # # 保存
        # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/save.png'
        # mouseClick(1, lOrR, img, reTry)
        #
        time.sleep(3)
        startDay = startDayAdd45


import datetime
import os
import pyautogui
import time
import xlrd
import pyperclip
from flash.zidshw.udyijm import searchMoveClick, dataExport
# 编号3 货主货位商品 正品
if __name__ == '__main__':
    # lOrR = 'left'
    pic_path = '/Users/flash/PycharmProjects/learnpython/flash/zidshw'
    # reTry = 1
    today = datetime.date.today()
    title = 'kuwzkucpuhpn'
    concont = str(today) + title

    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/tlvh.png'
    # mouseClick(2, lOrR, img, reTry)
    # 找到【台账】菜单
    img = os.path.join(pic_path, 'tlvh.png')
    searchMoveClick(img, 0, 0, 2)

    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/hovuhowzuhpn.png'
    # mouseClick(1, lOrR, img, reTry)
    # 找到【货主货位商品】菜单
    img = os.path.join(pic_path, 'hovuhowzuhpn.png')
    searchMoveClick(img, 0, 0, 1)

    pyautogui.moveTo(10 , 10)

    time.sleep(3)

    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/stockstatus.png'
    # location = pyautogui.locateCenterOnScreen(img, confidence=0.9)
    # print('________location__________>', location)
    # pyautogui.moveTo(location.x * 0.5 + 40, location.y * 0.5)
    # pyautogui.click()
    # 找到【库存状态】筛选项
    img = os.path.join(pic_path, 'stockstatus.png')
    searchMoveClick(img, 40, 0, 1)

    # 点击下拉菜单中的【正品】
    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/only_normal.png'
    # mouseClick(1, lOrR, img, reTry)
    # 找到【正品选项】菜单
    img = os.path.join(pic_path, 'only_normal.png')
    searchMoveClick(img, 0, 0, 1)

    # 点击下拉菜单中的【查询】
    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/inquire.png'
    # mouseClick(1, lOrR, img, reTry)
    # 找到【查询】按钮
    img = os.path.join(pic_path, 'inquire.png')
    searchMoveClick(img, 0, 0, 1)

    time.sleep(3)

    # 点击下拉菜单中的【导出】
    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/export.png'
    # mouseClick(1, lOrR, img, reTry)
    # 找到【导出】按钮
    img = os.path.join(pic_path, 'export.png')
    searchMoveClick(img, 0, 0, 1)

    pyautogui.typewrite(concont, interval=0.1)
    pyautogui.press('enter')

    # 点击下拉菜单中的【确定】
    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/sure.png'
    # mouseClick(1, lOrR, img, reTry)
    # 找到【确定】按钮
    img = os.path.join(pic_path, 'sure.png')
    searchMoveClick(img, 0, 0, 1)

    time.sleep(2)

    dataExport(pic_path, concont)
    # # 点击下拉菜单中的【任务管理】
    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/task_management.png'
    # mouseClick(1, lOrR, img, reTry)
    #
    # # 点击下拉菜单中的【导出任务管理】
    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/export_task_management.png'
    # mouseClick(1, lOrR, img, reTry)
    #
    # time.sleep(3)
    #
    # time.sleep(30)
    #
    # # 在文件名中搜索
    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/inquire.png'
    # location = pyautogui.locateCenterOnScreen(img, confidence=0.7)
    # pyautogui.moveTo(location.x * 0.5 - 50, location.y * 0.5)
    # pyautogui.click(clicks = 2)
    # pyautogui.typewrite(concont, interval=0.1)
    # pyautogui.press('enter')
    #
    #
    #
    # # 点击【查询】
    # pyautogui.moveTo(location.x * 0.5, location.y * 0.5)
    # pyautogui.click(clicks=1)
    #
    # time.sleep(2)
    #
    #
    # # 点击【下载】
    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/downloadV2.png'
    # mouseClick(1, lOrR, img, reTry)
    #
    # time.sleep(2)
    #
    # pyautogui.typewrite(concont, interval=0.1)
    # pyautogui.press('enter')
    #
    # # 选择保存目录
    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/choice.png'
    # mouseClick(1, lOrR, img, reTry)
    #
    # # 保存
    # img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/save.png'
    # mouseClick(1, lOrR, img, reTry)


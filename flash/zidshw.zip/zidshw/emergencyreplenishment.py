import datetime
import os
import pyautogui
import time
import xlrd
import pyperclip
from flash.zidshw.intercepted_Package_Detail import mouseClick

from pynput.mouse import Button, Controller as c_mouse
# 编号4 紧急补货任务数
from flash.zidshw.udyijm import searchMoveClick, dataExport

if __name__ == '__main__':
    pic_path = '/Users/flash/PycharmProjects/learnpython/flash/zidshw'
    today = datetime.date.today()
    todaydiminish1 = (today + datetime.timedelta(days=-1)).strftime("%Y-%m-%d")
    title = 'emergencyReplenishment'
    concont = str(today) + title
    mouse = c_mouse()

    # 找到【库内】
    img = os.path.join(pic_path, '3-kunz.png')
    searchMoveClick(img, 0, 0, 2)

    # 找到【补货预测】
    img = os.path.join(pic_path, '4-buhoyuce.png')
    searchMoveClick(img, 0, 0, 1)

    time.sleep(3)

    # 向下滑动窗口
    pyautogui.scroll(-7)

    # 找到【日期取消】
    img = os.path.join(pic_path, '4-quxc.png')
    searchMoveClick(img, 0, 0, 1)

    # 找到【查询】
    img = os.path.join(pic_path, '4-iaxp.png')
    searchMoveClick(img, 0, 0, 1)
    time.sleep(7)

    # 向上滑动窗口
    pyautogui.scroll(7)
    time.sleep(1)

    # 找到【导出】
    img = os.path.join(pic_path, '4-dkiu.png')
    searchMoveClick(img, 0, 0, 1)

    # 找到【异常分类】
    img = os.path.join(pic_path, '4-vuyi.png')
    searchMoveClick(img, 0, -25, 1)
    pyautogui.typewrite(concont, interval=0.1)
    pyautogui.press('enter')

    # 找到【确定】
    img = os.path.join(pic_path, '4-qtdy.png')
    # mouseClick(1, lOrR, img, reTry)
    searchMoveClick(img, 0, 0, 1)

    time.sleep(3)

    dataExport(pic_path, concont)














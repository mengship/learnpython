import pyautogui
import time
import xlrd
import pyperclip
import intercepted_Package_Detail

# 点击【下载】
lOrR = 'left'
reTry = 1
img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/downloadV2.png'
intercepted_Package_Detail.mouseClick(1, lOrR, img, reTry)
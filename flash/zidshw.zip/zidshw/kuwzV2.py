import datetime

import pyautogui
import time
import xlrd
import pyperclip

def mouseClick(clickTimes,lOrR,img,reTry):
    if reTry == 1:
        while True:
            try:
                location=pyautogui.locateCenterOnScreen(img, confidence=0.9)
                if location is not None:
                    pyautogui.click(location.x * 0.5, location.y * 0.5, clicks=clickTimes , interval=0.5 ,  duration=0, button=lOrR)
                    break
                print("未找到匹配图片,0.1秒后重试")
                time.sleep(0.1)
            except pyautogui.ImageNotFoundException:
                print('ImageNotFoundException: image not found')

    elif reTry == -1:
        while True:
            location=pyautogui.locateCenterOnScreen(img,confidence=0.9)
            if location is not None:
                pyautogui.click(location.x,location.y,clicks=clickTimes,interval=0.2,duration=0.2,button=lOrR)
            time.sleep(0.1)
    elif reTry > 1:
        i = 1
        while i < reTry + 1:
            location=pyautogui.locateCenterOnScreen(img,confidence=0.9)
            if location is not None:
                pyautogui.click(location.x,location.y,clicks=clickTimes,interval=0.2,duration=0.2,button=lOrR)
                print("重复")
                i += 1
            time.sleep(0.1)


if __name__ == '__main__':
    lOrR = 'left'

    reTry = 1
    today = datetime.date.today()
    title = 'kuwzkucpuhpn'
    concont = str(today) + title

    img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/tlvh.png'
    mouseClick(2, lOrR, img, reTry)

    img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/hovuhowzuhpn.png'
    mouseClick(1, lOrR, img, reTry)

    pyautogui.moveTo(10 , 10)

    time.sleep(3)

    img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/stockstatus.png'
    location = pyautogui.locateCenterOnScreen(img, confidence=0.9)
    print('________location__________>', location)
    pyautogui.moveTo(location.x * 0.5 + 40, location.y * 0.5)
    pyautogui.click()

    # 点击下拉菜单中的【正品】
    img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/only_normal.png'
    mouseClick(1, lOrR, img, reTry)

    # 点击下拉菜单中的【查询】
    img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/inquire.png'
    mouseClick(1, lOrR, img, reTry)

    time.sleep(3)

    # 点击下拉菜单中的【导出】
    img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/export.png'
    mouseClick(1, lOrR, img, reTry)

    pyautogui.typewrite(concont, interval=0.1)
    pyautogui.press('enter')

    # 点击下拉菜单中的【确定】
    img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/sure.png'
    mouseClick(1, lOrR, img, reTry)

    time.sleep(2)

    # 点击下拉菜单中的【任务管理】
    img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/task_management.png'
    mouseClick(1, lOrR, img, reTry)

    # 点击下拉菜单中的【导出任务管理】
    img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/export_task_management.png'
    mouseClick(1, lOrR, img, reTry)

    time.sleep(3)

    # 在文件名中搜索
    img = '/Users/flash/PycharmProjects/learnpython/flash/zidshw/inquire.png'
    location = pyautogui.locateCenterOnScreen(img, confidence=0.7)
    pyautogui.moveTo(location.x * 0.5 - 50, location.y * 0.5)
    pyautogui.click(clicks = 2)
    pyautogui.typewrite(concont, interval=0.1)
    pyautogui.press('enter')

    # 点击【查询】
    pyautogui.moveTo(location.x * 0.5, location.y * 0.5)
    pyautogui.click(clicks=1)



